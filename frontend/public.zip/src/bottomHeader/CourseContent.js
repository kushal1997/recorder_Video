import React from 'react'

export const CourseContent = () => {
  return (
    <>CourseContent</>
  )
}
