import React, { Fragment, useState } from "react";
import { BACKEND_URL } from "../config/constraints";
import "./css/uploadListCSS.css";
import { BottomHeader } from "../bottomHeader/BottomHeader";


export const UploadList = ({ medias }) => {
  const apiUrl = process.env.REACT_APP_BACKEND_URL;

  const [selectedVideo, setSelectedVideo] = useState(null);

  const handleVideoClick = (videoUrl) => {
    setSelectedVideo(videoUrl);
  };

  return (
    <Fragment>
      <section>
        <div className="container-fluid">
          {/* style={{ backgroundColor: 'rgb(36 0 0 / 88%)', backgroundSize: 'cover', padding: '40px 0px 130px 70px' }} */}
          <div className="row">
            <div className="col-md-9 video">
            <h4>
                Understand the JavaScript and technical concepts behind Node JS
              </h4>
              <div className="embed-responsive embed-responsive-16by9">
                {selectedVideo ? (
                  <div className="video-player">
                    <video
                      preload="auto"
                      width={640}
                      height={360}
                      controls
                      src={selectedVideo}
                    ></video>
                  </div>
                ) : (
                  <div className="video-player">
                    <video
                      preload="auto"
                      width={640}
                      height={360}
                      controls
                    ></video>
                  </div>
                )}
              </div>
              
            </div>

            <div className="col-md-3">
            <h3 style={{marginTop: '-5px'}}>Course Content</h3>
              <div className="content-list">
                <div
                  className="scroller"
                  data-wow-delay="00ms"
                  data-wow-duration="1500ms"
                  style={{ visibility: "visible" }}
                >
                  {medias &&
                    medias.map((media) => (
                      <div
                        key={media._id}
                        className={`playlist-item ${
                          selectedVideo === `${apiUrl}${media.videos[0]}`
                            ? "active"
                            : ""
                        }`}
                      >
                        <p
                          onClick={() =>
                            handleVideoClick(`${apiUrl}${media.videos[0]}`)
                          }
                        >
                          <input type="checkbox" id="check_box" />{" "}
                          &nbsp;&nbsp;&nbsp;
                          {media.name}
                          <br /><br />
                          <img
                            width="20"
                            height="20"
                            src="https://img.icons8.com/pastel-glyph/64/laptop-play-video--v1.png"
                            alt="laptop-play-video--v1"
                          />{" "}
                          <h6 >
                            {" "}
                            &nbsp; 16min32sec{" "}
                          </h6>
                        </p>
                      </div>
                    ))}
                  <p>
                    <input type="checkbox" id="check_box" /> 
                    Section 1 : Node js introduction Node js introduction
                    <br /><br />
                    <img
                      width="20"
                      height="20"
                      src="https://img.icons8.com/pastel-glyph/64/laptop-play-video--v1.png"
                      alt="laptop-play-video--v1"
                    />{" "}
                    <h6 > &nbsp;&nbsp;&nbsp; 16min32sec </h6>
                  </p>
                </div>
              </div>
            </div>

            {/* <div className="col-md-3">
              <h2 className="content-heading">COURSE CONTENT</h2>
            </div> */}
          </div>
        </div>

        <hr/>
        <BottomHeader />
<hr/>

      </section>
    </Fragment>
  );
};



// <div className="col-md-3">
// <img src={image} alt='img'/> 
// <div className="immersive-header-image">
//   <img src={image} alt="baner" height={150} width={295} />
// </div>
// <div className="immersive-header-container">
//   <div className="immersive-content">
//     <h2>Online Education Training For Node.js</h2>
//     <h5>Mr. Priyabrata Dash</h5>
//     <h6>10 videos &nbsp;&nbsp; Last Updated On Oct 10, 2023</h6>
//   </div>

//   <div className="circle">
//     <div className="meta-circle-button">
//       <i class="fa fa-facebook-f"></i>
//     </div>
//     <div className="meta-circle-button">
//       <i class="fa fa-linkedin"></i>
//     </div>
//     <div className="meta-circle-button">
//       <i class="fa fa-instagram"></i>
//     </div>
//   </div>

//   <div className="oval-btn">
//     <button type="button" className="btn btn-primary">
//       Contact Us
//     </button>
//     <button type="button" className="btn btn-primary0">
//       website
//     </button>
//   </div>
// </div>
// </div>